#!/bin/sh
# This script is called by cron at the scheduled time. $1 is the alarm-index and $2 the name of the alarm

alarm_index=$1
alarm_name=$2

case "$alarm_name" in
play)
	chumby_set_volume $(cat /psp/alarm_volume)
	cat /mnt/usb/events/play.bt.txt  >/tmp/.btplay-cmdin
	;;
touch)  
	# just for testing wether everything works
	touch /tmp/alarmtest.txt
        ;;
*)      
	# enter default action here
        ;;
esac
